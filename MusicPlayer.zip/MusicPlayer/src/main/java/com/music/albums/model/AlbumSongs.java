package com.music.albums.model;

public class AlbumSongs {

	private String songId;
	
	private int numPlays;
	
		
	public AlbumSongs(String songId, int numPlays) {
		super();
		this.songId = songId;
		this.numPlays = numPlays;
	}

	public String getSongId() {
		return songId;
	}

	public void setSongId(String songId) {
		this.songId = songId;
	}

	public int getNumPlays() {
		return numPlays;
	}

	public void setNumPlays(int numPlays) {
		this.numPlays = numPlays;
	}

	@Override
	public String toString() {
		return "AlbumSongs [songId=" + songId + ", numPlays=" + numPlays + "]";
	}
	
	
}
