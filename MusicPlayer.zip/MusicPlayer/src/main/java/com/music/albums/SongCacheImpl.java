package com.music.albums;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import com.music.albums.model.AlbumSongs;

public class SongCacheImpl implements SongCache {

	List<AlbumSongs> songs = new CopyOnWriteArrayList<AlbumSongs>();//We should not use class level variable but for test purpose used it

	/**
	* Record number of plays for a song.
	*/
	@Override
	synchronized public void recordSongPlays(String songId, int numPlays) {

		boolean songExist = songs.stream().filter(song -> songId.equals(song.getSongId())).findAny().isPresent();

		if (songExist) {
			for (AlbumSongs albumSongs : songs) {
				if (albumSongs.getSongId().equalsIgnoreCase(songId)) {
					albumSongs.setNumPlays(numPlays + albumSongs.getNumPlays());
					break;
				}
			}
		} else {
			songs.add(new AlbumSongs(songId, numPlays));
		}

	}

	/**
	* Fetch the number of plays for a song.
	*

	* @return the number of plays, or -1 if the
	song ID is unknown.
	*/
	@Override
	synchronized public int getPlaysForSong(String songId) {
		int numPlays = -1;
		for (AlbumSongs albumSongs : songs) {
			if (albumSongs.getSongId().equalsIgnoreCase(songId)) {
				numPlays = albumSongs.getNumPlays();
			}
		}
		return numPlays;

	}

	/**
	* 
	* Return the top N songs played, in descending
	order of number of plays.
	*/
	@Override
	synchronized public List<String> getTopNSongsPlayed(int n) {

		List<String> song = songs.stream().sorted(Comparator.comparing(AlbumSongs::getNumPlays).reversed()).limit(n)
				.map(AlbumSongs::getSongId).collect(Collectors.toList());
		return song;
	}

}
