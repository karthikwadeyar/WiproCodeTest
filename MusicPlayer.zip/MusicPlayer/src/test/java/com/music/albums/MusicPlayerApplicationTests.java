package com.music.albums;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInOrder.contains;

import org.hamcrest.collection.IsEmptyCollection;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicPlayerApplicationTests {

	@Test
	void contextLoads() {
		
		SongCache cache = new SongCacheImpl();
		cache.recordSongPlays("ID-1", 3);
		cache.recordSongPlays("ID-1", 1);
		cache.recordSongPlays("ID-2", 2);
		cache.recordSongPlays("ID-3", 5);
		
		assertThat(cache.getPlaysForSong("ID-1"), is(4));
		assertThat(cache.getPlaysForSong("ID-9"), is(-1));
		assertThat(cache.getTopNSongsPlayed(2), contains("ID-3",
		"ID-1"));
		assertThat(cache.getTopNSongsPlayed(0), IsEmptyCollection.empty());
		
	}

}
